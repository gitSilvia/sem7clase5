<?php
 define("USER", "root");
 define("SERVER", "localhost");
 define("BD", "store24");
define("PASS", "");
