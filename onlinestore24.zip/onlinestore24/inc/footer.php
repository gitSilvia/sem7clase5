<footer>
  <h3 class="text-center">Síguenos en</h3><br>
  <ul class="list-unstyled text-center">
    <li>
      <a href="#" class="social-icon all-elements-tooltip" data-toggle="tooltip" data-placement="bottom" title="Facebook">
        <img src="assets/icons/social-facebook.png" alt="facebook-icon">
      </a>
    </li>
    <li>
      <a href="#" class="social-icon all-elements-tooltip" data-toggle="tooltip" data-placement="bottom" title="Instagram">
        <img src="assets/icons/social-instagram.png" alt="instagram-icon">
      </a>
    </li>
  </ul>
  <br><br><br>
  <h5 class="text-center tittles-pages-logo">LP3 Electronics &copy; <?php echo date("Y"); ?>
  </h5>
</footer>
